﻿using Microsoft.EntityFrameworkCore;
using U1P1_CRUD_21340479.Models.Pets;

namespace U1P1_CRUD_21340479.Data
{
    public class PetDbContext : DbContext
    {
        public PetDbContext(DbContextOptions<PetDbContext> options) : base(options)
        {
        }
        // Dbset properties represent tables in the database
        public DbSet<PetType> Types { get; set; }
        public DbSet<Breed> Breeds { get; set; }
        public DbSet<Pet> Pets { get; set; }
    }
}
