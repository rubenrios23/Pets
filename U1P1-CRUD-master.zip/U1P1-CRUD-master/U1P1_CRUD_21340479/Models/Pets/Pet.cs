﻿namespace U1P1_CRUD_21340479.Models.Pets
{
    public class Pet
    {
        public int ID { get; set; }
        public string? Name { get; set; }
        public int Age { get; set; }
        public string? Color { get; set; }

        // Create Foreign Keys
        public int PetTypeID { get; set; }
        public int BreedID { get; set; }

        // Navigation Properties
        public virtual PetType PetType { get; set; } = null!;
        public virtual Breed Breed { get; set; } = null!;
    }
}
