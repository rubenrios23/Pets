﻿namespace U1P1_CRUD_21340479.Models.Pets
{
    public class Breed
    {
        public int ID { get; set; }
        public string? Description { get; set; }
        public virtual ICollection<Pet> Pets { get; set; } = new List<Pet>();
    }
}
